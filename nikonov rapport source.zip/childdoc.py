
# 3.1
class RedditDocument(Document):
# 3.1  on appelle le constructeur pour initialiser cette class
  def __init__(self, title, text, doc):
    json = {'title': title, 'date': doc['date'], 'url': doc['url'], 'text': text}
# ici nous appellons le method __init__ of parent
    super().__init__(json)
    self.ncomment = doc['num_comments']
    self.author = doc['author']
    self.type = 'reddit'

  def increment_ncomment(self):
    self.ncomment += 1

  def get_ncomment(self):
    return f'Comment quantity: {self.ncomment}'

  @staticmethod
  def get_text_key():
    return 'body'


# 3.2
class ArxivDocument(Document):
# 3.2  on appelle le constructeur pour initialiser cette class
  def __init__(self, title, text, doc):
    json = {'title': title, 'date': doc['published'], 'url': doc['link'], 'text': text}
    # ici nous appellons le method __init__ of parent
    super().__init__(json)
    authors = doc['author']
    self.authors = [a['name'] for a in authors] if len(authors) != 1 else [authors['name']]
    self.type = 'arxiv'

  def add_coauthors(self, aut):
    self.authors.append(aut)

  def get_authors(self):
    return f'Author list: {self.authors}'

  @staticmethod
  def get_text_key():
    return 'summary'
