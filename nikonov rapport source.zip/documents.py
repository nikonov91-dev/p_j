from gensim.summarization.summarizer import summarize

class Document():
#  2.1
  def __init__(self, json):
    self.json = json
    self.type = None

# 3.4 Here is the type getter is set
  def get_type(self):
    return self.type

# cet setter permet de change le document
  def set_json(self, json):
    for key in json:
      self.json[key] = json[key] if self.json[key] is not None else None

  def __json__(self):
    return {
      'titre': self.json['titre'],
      'date': self.json['date'],
      'url': self.json['url'],
      'text': self.json['text']
    }

# 2.2
# on ecrase la method str pour fournire l'information qu'on a besoin (p.e. pour print operateur)
  def __str__(self):
    return f'Document: {self.json["title"]}'

# 2.8
# on ecrase la method repr pour fournire l'information qu'on a besoin
  def __repr__(self):
    return f'Doc title: {self.json["title"]}, release date: {self.json["date"]}'

  # 4.3
  def summarize_me(self):
    return summarize(self.json['text'])

